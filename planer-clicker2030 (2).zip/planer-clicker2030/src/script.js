document.getElementsByTagName("h1")[0].style.fontSize = "6vw";let energy = 0;
let perClick = 1;
let autoRate = 0;

let clickCost = 10;
let autoCost = 25;

const energyDisplay = document.getElementById("energy");
const perClickDisplay = document.getElementById("perClick");
const autoRateDisplay = document.getElementById("autoRate");

const clickCostDisplay = document.getElementById("clickCost");
const autoCostDisplay = document.getElementById("autoCost");

const planet = document.getElementById("planet");

planet.addEventListener("click", () => {
    energy += perClick;
    updateUI();
});

document.getElementById("clickUpgrade").addEventListener("click", () => {
    if (energy >= clickCost) {
        energy -= clickCost;
        perClick++;
        clickCost = Math.floor(clickCost * 1.8);
        updateUI();
    }
});

document.getElementById("autoUpgrade").addEventListener("click", () => {
    if (energy >= autoCost) {
        energy -= autoCost;
        autoRate++;
        autoCost = Math.floor(autoCost * 2);
        updateUI();
    }
});

setInterval(() => {
    energy += autoRate;
    updateUI();
}, 1000);

function updateUI() {
    energyDisplay.textContent = energy;
    perClickDisplay.textContent = perClick;
    autoRateDisplay.textContent = autoRate;

    clickCostDisplay.textContent = clickCost;
    autoCostDisplay.textContent = autoCost;
}

updateUI();