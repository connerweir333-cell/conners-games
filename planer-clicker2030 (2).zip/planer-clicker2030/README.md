# planer clicker2030

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Conner-Weir/pen/019eb60e-5d0b-7906-bcbf-c7104d1dbc02](https://codepen.io/editor/Conner-Weir/pen/019eb60e-5d0b-7906-bcbf-c7104d1dbc02).

